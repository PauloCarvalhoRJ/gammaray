
# h1
## h2
### h3
#### h4
##### h5
###### h6

h1
==

h2
--

--------------------

    indented code

```
fenced code
```

<tag attr='val' attr2="val2">

> quote

* list item
1. list item

[ref]: /url

paragraph
&copy; &#1234; &#xabcd;
`code`
*emph* **strong** ***strong emph***
_emph_ __strong__ ___strong emph___
[ref] [ref][] [link](/url)
![ref] ![ref][] ![img](/url)
<http://example.com> <doe@example.com>
\\ \* \. \` \
