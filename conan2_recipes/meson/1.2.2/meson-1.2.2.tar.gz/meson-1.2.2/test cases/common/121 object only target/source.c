int func1_in_obj(void) {
    return 0;
}
