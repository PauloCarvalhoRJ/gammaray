// cmMod.hpp (D)
#pragma once

#error "cmMod.hpp in incD must not be included"
