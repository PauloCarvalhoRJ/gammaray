# Benchmark

The Visual Studio project in this folder contains benchmarks to analyze different way of
decoding and encoding functions.

The project expects that the Google Benchmark framework has been installed with vcpkg.  
This can be done with: ```vcpkg install benchmark```
