// Copyright (c) Team CharLS.
// SPDX-License-Identifier: BSD-3-Clause

#pragma once

void test_conformance();
void test_color_transforms_hp_images();
void test_sample_annex_h3();
