The C/C++ samples applications are created for simplicity and to demonstrate
how the use the CharLS API. They are not production quality. In particular they
should not be installed in binary distribution as reference command line utils
