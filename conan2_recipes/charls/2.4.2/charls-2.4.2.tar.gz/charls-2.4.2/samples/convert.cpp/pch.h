// Copyright (c) Team CharLS.
// SPDX-License-Identifier: BSD-3-Clause

#pragma once

#include <charls/charls.h>

#include <cassert>
#include <cstring>
#include <iostream>
#include <vector>
