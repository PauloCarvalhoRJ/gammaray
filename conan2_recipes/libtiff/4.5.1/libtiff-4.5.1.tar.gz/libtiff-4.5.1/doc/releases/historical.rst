Old release history
===================

Older LibTIFF releases.

.. toctree::
    :maxdepth: 1
    :titlesonly:

    v3.9.5
    v3.9.4
    v3.9.3
    v3.9.2
    v3.9.1
    v3.9.0
    v3.9.0beta
    v3.8.2
    v3.8.1
    v3.8.0
    v3.7.4
    v3.7.3
    v3.7.2
    v3.7.1
    v3.7.0
    v3.7.0beta2
    v3.7.0beta
    v3.7.0alpha
    v3.6.1
    v3.6.0
    v3.5.7
    v3.5.6beta
    v3.5.5
    v3.5.4
    v3.5.3
    v3.5.2
    v3.5.1
    v3.4beta036
    v3.4beta035
    v3.4beta034
    v3.4beta033
    v3.4beta032
    v3.4beta031
    v3.4beta029
    v3.4beta028
    v3.4beta024
    v3.4beta018
    v3.4beta016
    v3.4beta007
