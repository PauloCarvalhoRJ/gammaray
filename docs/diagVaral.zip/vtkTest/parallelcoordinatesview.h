#ifndef PARALLELCOORDINATESVIEW_H
#define PARALLELCOORDINATESVIEW_H

#include <QWidget>
#include <QHBoxLayout>
#include <vtkAutoInit.h>
#ifndef _VTK_MODULE_INIT_
#define _VTK_MODULE_INIT_
VTK_MODULE_INIT(vtkRenderingOpenGL2);
VTK_MODULE_INIT(vtkInteractionStyle);
VTK_MODULE_INIT(vtkRenderingFreeType);
#endif
#include "QVTKOpenGLWidget.h"
#include "vtkGenericOpenGLRenderWindow.h"
#include <vtkPolyData.h>
#include <vtkDelimitedTextReader.h>
#include <vtkTable.h>
#include <vtkPointData.h>
#include <vtkParallelCoordinatesView.h>
#include <vtkParallelCoordinatesRepresentation.h>
#include "vtkRenderer.h"
#include "vtkRenderWindow.h"
#include "vtkRenderWindowInteractor.h"
#include <vtkTable.h>
#include <vtkDelimitedTextReader.h>
#include <vtkStringArray.h>
#include <vtkDoubleArray.h>
#include <vtkFloatArray.h>
#include <vtkIntArray.h>
#include <vtksys/SystemTools.hxx>

namespace Ui {
class ParallelCoordinatesView;
}

class ParallelCoordinatesView : public QWidget
{
    Q_OBJECT

public:
    explicit ParallelCoordinatesView(QVTKOpenGLWidget *OGLWidget, QWidget *widget, QWidget *parent = 0);
    ~ParallelCoordinatesView();
    void View(QString filenName);

private:
    Ui::ParallelCoordinatesView *ui;
    vtkSmartPointer<vtkRenderer>                            renderer;
    vtkSmartPointer<vtkGenericOpenGLRenderWindow>           renderWindow;
    //vtkSmartPointer<vtkRenderWindow>                        renderWindow;
    vtkSmartPointer<vtkRenderWindowInteractor>              renderWindowInteractor;
    vtkSmartPointer<vtkTable>                               table;
    vtkSmartPointer<vtkDelimitedTextReader>                 reader;
    vtkSmartPointer<vtkPolyData>                            polydata;
    vtkSmartPointer<vtkParallelCoordinatesRepresentation>   rep;
    vtkSmartPointer<vtkParallelCoordinatesView>             view;
};

#endif // PARALLELCOORDINATESVIEW_H
