#include "parallelcoordinatesview.h"
#include "ui_parallelcoordinatesview.h"

ParallelCoordinatesView::ParallelCoordinatesView(QVTKOpenGLWidget *OGLWidget, QWidget *widget, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ParallelCoordinatesView)
{
    ui->setupUi(this);
    ui->setupUi(this);
    QHBoxLayout * layout = new QHBoxLayout();
    layout->addWidget(OGLWidget);
    widget->setLayout(layout);

    renderWindow            = vtkSmartPointer<vtkGenericOpenGLRenderWindow>::New();

    table                   = vtkSmartPointer<vtkTable>::New();
    reader                  = vtkSmartPointer<vtkDelimitedTextReader>::New();
    polydata                = vtkSmartPointer<vtkPolyData>::New();
    rep                     = vtkSmartPointer<vtkParallelCoordinatesRepresentation>::New();
    view                    = vtkSmartPointer<vtkParallelCoordinatesView>::New();

    //Do not create a new renderer, use the view's renderer.
    renderer = view->GetRenderer();

    //Both the view and the Qt widget must share the same render window
    view->SetRenderWindow( renderWindow );
    OGLWidget->SetRenderWindow( renderWindow );

    renderWindowInteractor  = renderWindow->GetInteractor();
    renderWindowInteractor->SetRenderWindow(renderWindow);
    renderer->SetBackground(1.0, 1.0, 1.0);
    renderer->GradientBackgroundOff();
    renderWindow->AddRenderer(renderer);
}

ParallelCoordinatesView::~ParallelCoordinatesView()
{
    delete ui;
}

void ParallelCoordinatesView::View(QString fileName)
{
    std::string title;
    std::string inputFilename = fileName.toStdString();

    reader->SetFileName(inputFilename.c_str());
    reader->SetHaveHeaders(1);
    reader->DetectNumericColumnsOn();
    reader->SetFieldDelimiterCharacters(",");
    reader->Update();

    table = reader->GetOutput();
    title = vtksys::SystemTools::GetFilenameWithoutExtension(
                vtksys::SystemTools::GetFilenameName(inputFilename));

    for (vtkIdType i = 0; i < table->GetNumberOfColumns(); ++i)
        polydata->GetPointData()->AddArray(table->GetColumn(i));

    rep->SetInputData(polydata);

    for (vtkIdType i = 0; i < table->GetNumberOfColumns(); ++i)
    {
        if (vtkStringArray::SafeDownCast(table->GetColumn(i)))
            continue;
        else
            rep->SetInputArrayToProcess(i, 0, 0, 0, table->GetColumn(i)->GetName());
    }

    rep->SetFontSize(.5);
    rep->SetPlotTitle(title.c_str());
    rep->SetLineOpacity(0.5);
    rep->SetLineColor(0.7, 0.7, 0.7);
    rep->SetAxisColor(0.0, 0.0, 0.0);
    rep->SetAxisLabelColor(0.0, 0.0, 0.0);

    // Set up the Parallel Coordinates View and hook in the Representation
    view->SetRepresentation(rep);
    view->SetInspectMode(1);
    view->SetDisplayHoverText(1);

    // Brush Mode determines the type of interaction you perform to select data
    view->SetBrushModeToLasso();
    view->SetBrushOperatorToReplace();

    view->ResetCamera();
    view->Render();
    view->GetInteractor()->Start();
}
