#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    OGLWidget = new QVTKOpenGLWidget();
    widget2 = new ParallelCoordinatesView(OGLWidget, ui->widget);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString fileName = QFileDialog::getOpenFileName( this, tr("Open File"), QDir::homePath(), "CSV Files (*.csv)" );
    widget2->View(fileName);
}
