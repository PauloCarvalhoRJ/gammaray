The GSLIB90 executable are placed in the installation directory. No icons are created for them as they are DOS executables.

They can be executed from the command prompt, or called by WinGslib.
